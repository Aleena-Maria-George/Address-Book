#include <stdio.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook)
{
    FILE *file = fopen("contacts.csv", "w"); // Open file in write mode (overwrites existing content)
    if (file == NULL)
    {
        printf("Error: Could not open file for saving.\n");
        return;
    }

    Contact *contact = &addressBook->contacts[addressBook->contactCount - 1];
    fprintf(file, "%s,%s,%s\n", contact->name, contact->phone, contact->email);

    fclose(file); // Close the file
    printf("Contacts saved successfully to file.\n");
}

void loadContactsFromFile(AddressBook *addressBook)
{
    FILE *file = fopen("contacts.csv", "r");
    if (file == NULL)
    {
        printf("No contact file found. Starting with default contacts.\n");
        return; // No file means no contacts to load
    }

    char line[100];
    while (fgets(line, sizeof(line), file) && addressBook->contactCount < MAX_CONTACTS)
    {
        Contact temp;
        sscanf(line, "%[^,],%[^,],%s", temp.name, temp.phone, temp.email);
        addressBook->contacts[addressBook->contactCount++] = temp;
    }
    fclose(file);
    printf("Contacts loaded from file successfully.\n");
}